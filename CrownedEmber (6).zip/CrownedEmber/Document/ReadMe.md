Crowned Ember Website
Description

Crowned Ember is a responsive luxury restaurant website located in Hyde Park. The site showcases the restaurant’s about us, menu, awards, 
contact, and enquiry pages. 
It is designed for both desktop and mobile devices, providing an elegant and user-friendly experience for visitors.

Features

Responsive design for desktop and mobile.

Brunch and dinner menus with images.

Awards page showcasing recognitions.

Contact and enquiry forms with email integration.

Interactive homepage slideshow including images and video.

Usage

Navigate through the site using the header navigation links.

Submit messages via the Contact or Enquiry forms.

Explore the menu images and the slideshow on the homepage.


https://github.com/SabeliweMkhulisa/WEDE5020P2.git