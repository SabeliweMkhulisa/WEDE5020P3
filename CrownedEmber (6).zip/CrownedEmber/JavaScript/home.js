document.addEventListener("DOMContentLoaded", () => {
    //  1. Heading shimmer + typewriter 
    const style = document.createElement("style");
    style.textContent = `
        @keyframes shimmer {
            0% { background-position: -200% center; }
            100% { background-position: 200% center; }
        }
        .shimmer-gold {
            background: linear-gradient(90deg,#FFD700,#FFF8DC,#FFD700,#FFF8DC);
            background-size: 200%;
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            animation: shimmer 2s linear infinite;
        }
    `;
    document.head.appendChild(style);

    const heading = document.querySelector("main h2");
    heading.textContent = "";
    heading.classList.add("shimmer-gold");

    const text = "Welcome to Crowned Ember";
    let i = 0;
    (function typeWriter() {
        if (i < text.length) {
            heading.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 120);
        }
    })();

    //  2. Slideshow autoplay 
    const slides = document.querySelectorAll(".slideshow .slide");
    let slideIndex = 0;
    function showSlides() {
        slides.forEach((s, idx) => s.style.display = idx === slideIndex ? "block" : "none");
        slideIndex = (slideIndex + 1) % slides.length;
        setTimeout(showSlides, 5000); // Change slide every 5 sec
    }
    showSlides();

    //  3. Gallery/lightbox 
    const galleryImages = document.querySelectorAll(".extra-images img");
    const lightbox = document.getElementById("galleryLightbox");
    const lightboxImg = document.getElementById("galleryImg");
    const closeBtn = document.querySelector(".lightbox .close");
    const nextBtn = document.querySelector(".next");
    const prevBtn = document.querySelector(".prev");
    let currentIndex = 0;

    function showImage(index) {
        lightbox.style.display = "block";
        lightboxImg.src = galleryImages[index].src;
        currentIndex = index;
    }

    galleryImages.forEach((img, idx) => {
        img.addEventListener("click", () => showImage(idx));
    });

    closeBtn.addEventListener("click", () => lightbox.style.display = "none");

    nextBtn.addEventListener("click", () => {
        currentIndex = (currentIndex + 1) % galleryImages.length;
        showImage(currentIndex);
    });

    prevBtn.addEventListener("click", () => {
        currentIndex = (currentIndex - 1 + galleryImages.length) % galleryImages.length;
        showImage(currentIndex);
    });

    lightbox.addEventListener("click", (e) => {
        if (e.target === lightbox) lightbox.style.display = "none";
    });

    //  4. Optional: Scroll-to-top button
    const upBtn = document.createElement("button");
    upBtn.textContent = "Up";
    Object.assign(upBtn.style, {
        position: "fixed",
        bottom: "30px",
        right: "30px",
        padding: "10px 15px",
        borderRadius: "50px",
        border: "none",
        background: "gold",
        color: "#111",
        cursor: "pointer",
        display: "none",
        zIndex: "1000",
    });
    document.body.appendChild(upBtn);

    window.addEventListener("scroll", () => {
        upBtn.style.display = window.scrollY > 200 ? "block" : "none";
    });

    upBtn.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });
});
