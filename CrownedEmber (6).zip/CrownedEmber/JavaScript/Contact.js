document.addEventListener("DOMContentLoaded", () => {
    const heading = document.querySelector("main h2");
    const text = "Contact Us";
    let index = 0;

    heading.textContent = "";

    const form = document.querySelector("#contactForm");
    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");

    const successMsg = document.createElement("p");
    successMsg.style.textAlign = "center";
    successMsg.style.marginTop = "10px";
    form.appendChild(successMsg);

    function validateName() {
        const lettersOnly = /^[A-Za-z\s]+$/;
        return lettersOnly.test(nameInput.value.trim());
    }

    function validateEmail() {
        const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return validEmail.test(emailInput.value.trim());
    }

    function typeLetter() {
        if (index < text.length) {
            heading.textContent += text[index];
            index++;
            setTimeout(typeLetter, 150);
        } else {
            shimmerEffect();
        }
    }

    function shimmerEffect() {
        heading.style.background = "linear-gradient(90deg, gold, white, gold)";
        heading.style.webkitBackgroundClip = "text";
        heading.style.webkitTextFillColor = "transparent";
        heading.style.animation = "shimmer 2s infinite";
        const style = document.createElement("style");
        style.textContent = `
            @keyframes shimmer {
                0% { background-position: -200% 0; }
                100% { background-position: 200% 0; }
            }
        `;
        document.head.appendChild(style);
    }

    typeLetter();

    emailjs.init("xyFB6iNQE9UFV0NJw");

    form.addEventListener("submit", (e) => {
        e.preventDefault();
        if (!validateName()) {
            successMsg.textContent = "Name can only contain letters";
            successMsg.style.color = "red";
            return;
        }
        if (!validateEmail()) {
            successMsg.textContent = "Please enter a valid email";
            successMsg.style.color = "red";
            return;
        }

        emailjs.sendForm("service_bw115ka", "template_mmc1piq", form)
            .then(() => {
                successMsg.textContent = "Enquiry sent successfully!";
                successMsg.style.color = "#FFD700";
                form.reset();
            })
            .catch(err => {
                console.error(err);
                successMsg.textContent = "Oops! Something went wrong.";
                successMsg.style.color = "red";
            });
    });
});
