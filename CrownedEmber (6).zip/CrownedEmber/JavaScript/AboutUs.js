document.addEventListener("DOMContentLoaded", () => {

 
  const aboutTitle = document.querySelector("main h2");
  if (aboutTitle) {
    const text = "About Us";
    aboutTitle.textContent = ""; 

    let index = 0;

    // shimmer styling for title while typing
    aboutTitle.style.transition = "0.3s ease-in-out";

    function type() {
      if (index < text.length) {
        aboutTitle.textContent += text.charAt(index);
        aboutTitle.style.textShadow = "0 0 10px gold, 0 0 20px gold";
        aboutTitle.style.color = "gold";

        index++;
        setTimeout(type, 150);
      } else {
        // stop shimmer once typing is done
        aboutTitle.style.textShadow = "none";
      }
    }

    type();
  }


     //Fade-in paragraphs

  const paragraphs = document.querySelectorAll("main p");

  paragraphs.forEach((p, i) => {
    p.style.opacity = "0";
    p.style.transform = "translateY(20px)";
    p.style.transition = "opacity 1s ease, transform 1s ease";

    setTimeout(() => {
      p.style.opacity = "1";
      p.style.transform = "translateY(0)";
    }, 400 + (i * 300));
  });


    // Auto slideshow (no arrows)

  const slides = document.querySelectorAll(".slideshow img");
  let slideIndex = 0;

  slides.forEach(img => {
    img.style.position = "absolute";
    img.style.top = "0";
    img.style.left = "0";
    img.style.width = "100%";
    img.style.opacity = "0";
    img.style.transition = "opacity 1s ease-in-out";
  });

  function showSlides() {
    slides.forEach(img => (img.style.opacity = "0"));
    slides[slideIndex].style.opacity = "1";

    slideIndex = (slideIndex + 1) % slides.length;
    setTimeout(showSlides, 4000);
  }

  if (slides.length > 0) showSlides();

  
     //UP Button
  
  const upButton = document.createElement("button");
  upButton.id = "up-btn";
  upButton.textContent = "UP";

  upButton.style.position = "fixed";
  upButton.style.bottom = "20px";
  upButton.style.right = "20px";
  upButton.style.background = "gold";
  upButton.style.color = "black";
  upButton.style.border = "none";
  upButton.style.padding = "10px 15px";
  upButton.style.borderRadius = "6px";
  upButton.style.fontWeight = "bold";
  upButton.style.boxShadow = "0 0 10px gold";
  upButton.style.cursor = "pointer";
  upButton.style.display = "none";
  upButton.style.zIndex = "1000";

  document.body.appendChild(upButton);

  window.addEventListener("scroll", () => {
    upButton.style.display = window.scrollY > 300 ? "block" : "none";
  });

  upButton.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

});
