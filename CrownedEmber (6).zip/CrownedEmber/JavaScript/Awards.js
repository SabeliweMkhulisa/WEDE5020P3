document.addEventListener("DOMContentLoaded", () => {
  
    // Typing effect for "Our Awards"

  const awardsTitle = document.querySelector("main h2");
  if (awardsTitle) {
    const text = awardsTitle.textContent.trim();
    awardsTitle.textContent = "";

    // Create a blinking cursor
    const cursor = document.createElement("span");
    cursor.textContent = "|";
    cursor.style.color = "gold";
    cursor.style.marginLeft = "4px";
    cursor.style.animation = "blink 0.8s infinite";
    awardsTitle.appendChild(cursor);

    let index = 0;
    function type() {
      if (index < text.length) {
        awardsTitle.insertBefore(
          document.createTextNode(text.charAt(index)),
          cursor
        );
        index++;
        setTimeout(type, 150);
      } else {
        cursor.style.display = "none";
      }
    }
    type();
  }

 
    // Fade in the list items and images
 
  const fadeElements = document.querySelectorAll("main ul li, main img");
  fadeElements.forEach(el => {
    el.style.opacity = "0";
    el.style.transform = "translateY(20px)";
    el.style.transition = "opacity 1s ease, transform 1s ease";
  });

  setTimeout(() => {
    fadeElements.forEach((el, i) => {
      setTimeout(() => {
        el.style.opacity = "1";
        el.style.transform = "translateY(0)";
      }, i * 300); // stagger animation
    });
  }, 500);


     //Shimmer effect on footer

  const footerElements = document.querySelectorAll("footer p");
  footerElements.forEach(el => {
    el.addEventListener("mouseover", () => {
      el.style.textShadow =
        "0 0 10px gold, 0 0 20px #ffeb3b, 0 0 40px gold, 0 0 80px #fff9c4";
      el.style.color = "gold";
    });
    el.addEventListener("mouseout", () => {
      el.style.textShadow = "none";
      el.style.color = "#ccc";
    });
  });

  
    // "UP" Button
  
  const upButton = document.createElement("button");
  upButton.id = "up-btn";
  upButton.textContent = "up";
  upButton.style.position = "fixed";
  upButton.style.bottom = "20px";
  upButton.style.right = "20px";
  upButton.style.background = "gold";
  upButton.style.border = "none";
  upButton.style.borderRadius = "8px";
  upButton.style.padding = "8px 12px";
  upButton.style.cursor = "pointer";
  upButton.style.fontWeight = "bold";
  upButton.style.boxShadow = "0 0 10px gold";
  upButton.style.transition = "0.3s";
  upButton.style.zIndex = "1000";
  upButton.style.display = "none";
  document.body.appendChild(upButton);

  window.addEventListener("scroll", () => {
    upButton.style.display = window.scrollY > 300 ? "block" : "none";
  });

  upButton.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
});


  // Keyframes for cursor blink

const style = document.createElement("style");
style.innerHTML = `
@keyframes blink {
  0%, 50%, 100% { opacity: 1; }
  25%, 75% { opacity: 0; }
}`;
document.head.appendChild(style);

