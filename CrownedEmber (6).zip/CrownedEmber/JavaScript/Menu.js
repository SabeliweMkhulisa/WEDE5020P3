document.addEventListener("DOMContentLoaded", () => {
 
 
  const menuTitle = document.querySelector("main h2");
  if (menuTitle) {
    const text = menuTitle.textContent.trim();
    menuTitle.textContent = "";

    const cursor = document.createElement("span");
    cursor.textContent = "|";
    cursor.style.color = "gold";
    cursor.style.marginLeft = "4px";
    cursor.style.animation = "blink 0.8s infinite";
    menuTitle.appendChild(cursor);

    let index = 0;
    function type() {
      if (index < text.length) {
        menuTitle.insertBefore(
          document.createTextNode(text.charAt(index)),
          cursor
        );
        index++;
        setTimeout(type, 150);
      } else {
        cursor.style.display = "none";
      }
    }
    type();

    menuTitle.classList.add("shimmer-hover");
  }


    // Fade-in for sections and images
  
  const fadeElements = document.querySelectorAll("main h3, main ul, main img");
  fadeElements.forEach((el, i) => {
    el.style.opacity = 0;
    el.style.transition = "opacity 1s ease-in-out";
    setTimeout(() => {
      el.style.opacity = 1;
    }, i * 200 + 500);
  });

  
     //Footer shimmer
  
  const footer = document.querySelector("footer");
  footer.classList.add("shimmer-hover-footer");

  
     //"UP" Button

  const upButton = document.createElement("button");
  upButton.id = "up-btn";
  upButton.textContent = "up";
  upButton.classList.add("up-button");
  document.body.appendChild(upButton);

  window.addEventListener("scroll", () => {
    upButton.style.display = window.scrollY > 300 ? "block" : "none";
  });

  upButton.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });


    // Hamburger menu toggle class
 
  const menuToggle = document.getElementById("menu-toggle");
  const navLinks = document.querySelector(".nav-links");

  menuToggle.addEventListener("change", () => {
    if (menuToggle.checked) {
      navLinks.classList.add("hamburger-open");
    } else {
      navLinks.classList.remove("hamburger-open");
    }
  });


     //Mobile adjustments for menu images and options

  function adjustMobileMenu() {
    if (window.innerWidth <= 768) {
      const allImgs = document.querySelectorAll("main img");
      allImgs.forEach(img => {
        img.style.display = "inline-block";
        img.style.width = "250px";
        img.style.height = "250px";
        img.style.margin = "10px 5px";
        img.style.objectFit = "cover";
      });

      const allLists = document.querySelectorAll("main ul");
      allLists.forEach(list => {
        list.style.width = "95%";
        list.style.margin = "10px auto";
        list.style.padding = "0";
      });
    } else {
      const allImgs = document.querySelectorAll("main img");
      allImgs.forEach(img => {
        img.style.display = "";
        img.style.width = "";
        img.style.height = "";
        img.style.margin = "";
        img.style.objectFit = "";
      });

      const allLists = document.querySelectorAll("main ul");
      allLists.forEach(list => {
        list.style.width = "";
        list.style.margin = "";
        list.style.padding = "";
      });
    }
  }

  window.addEventListener("resize", adjustMobileMenu);
  adjustMobileMenu(); // run once on load
});


  // Keyframes and shimmer

const style = document.createElement("style");
style.innerHTML = `
@keyframes blink {
  0%, 50%, 100% { opacity: 1; }
  25%, 75% { opacity: 0; }
}
.shimmer-hover:hover {
  text-shadow: 0 0 10px gold, 0 0 20px #ffeb3b, 0 0 40px gold, 0 0 80px #fff9c4;
  color: gold;
}
.shimmer-hover-footer:hover {
  color: gold;
  text-shadow: 0 0 10px gold, 0 0 20px #ffeb3b, 0 0 40px gold, 0 0 80px #fff9c4;
}
.up-button {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background: gold;
  border: none;
  border-radius: 8px;
  padding: 8px 12px;
  cursor: pointer;
  font-weight: bold;
  box-shadow: 0 0 10px gold;
  transition: 0.3s;
  z-index: 1000;
  display: none;
}
.hamburger-open a {
  background: gold;
  color: black;
}
`;
document.addEventListener("DOMContentLoaded", () => {

    // Mobile horizontal scroll for images
 
  const allImgs = document.querySelectorAll("main img");

  // Wrap each group of 3 images into a scrollable container
  const main = document.querySelector("main");
  const imgGroups = [];
  let tempGroup = [];

  allImgs.forEach((img, i) => {
    tempGroup.push(img);
    if ((i + 1) % 3 === 0 || i === allImgs.length - 1) {
      imgGroups.push(tempGroup);
      tempGroup = [];
    }
  });

  imgGroups.forEach(group => {
    const wrapper = document.createElement("div");
    wrapper.classList.add("img-scroll-container");
    group[0].parentNode.insertBefore(wrapper, group[0]);
    group.forEach(img => wrapper.appendChild(img));
  });

 
     //Adjust images and menu for mobile
 
  function adjustMobileMenu() {
    const width = window.innerWidth;
    const lists = document.querySelectorAll("main ul");

    if (width <= 768) {
      // Make images scrollable horizontally
      const scrollContainers = document.querySelectorAll(".img-scroll-container");
      scrollContainers.forEach(container => {
        container.style.display = "flex";
        container.style.overflowX = "auto";
        container.style.gap = "10px";
        container.style.padding = "10px 0";
      });

      allImgs.forEach(img => {
        img.style.width = "250px";
        img.style.height = "250px";
        img.style.flex = "0 0 auto";
        img.style.objectFit = "cover";
      });

      // Make menu list items fit inside viewport
      lists.forEach(list => {
        list.style.width = "95%";
        list.style.margin = "10px auto";
        list.style.fontSize = "0.95rem";
        list.style.lineHeight = "1.2rem";
      });
    } else {
      // Reset for desktop
      const scrollContainers = document.querySelectorAll(".img-scroll-container");
      scrollContainers.forEach(container => {
        container.style.display = "";
        container.style.overflowX = "";
        container.style.gap = "";
        container.style.padding = "";
      });

      allImgs.forEach(img => {
        img.style.width = "";
        img.style.height = "";
        img.style.flex = "";
        img.style.objectFit = "";
      });

      lists.forEach(list => {
        list.style.width = "";
        list.style.margin = "";
        list.style.fontSize = "";
        list.style.lineHeight = "";
      });
    }
  }

  window.addEventListener("resize", adjustMobileMenu);
  adjustMobileMenu();
});

document.head.appendChild(style);
