document.addEventListener("DOMContentLoaded", () => {

    //Shimmer typing effect for heading 
    const heading = document.querySelector("main h2");
    const text = "Enquiry Form";
    heading.textContent = "";
    heading.style.backgroundImage = "linear-gradient(90deg, #FFD700, #FFF8DC, #FFD700)";
    heading.style.backgroundClip = "text";
    heading.style.webkitBackgroundClip = "text";
    heading.style.color = "transparent";
    heading.style.textShadow = "0 0 6px rgba(255,215,0,0.5)";
    heading.style.animation = "shimmer 2s linear infinite";

    const style = document.createElement("style");
    style.textContent = `
        @keyframes shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
    `;
    document.head.appendChild(style);

    let i = 0;
    (function typeWriter() {
        if (i < text.length) {
            heading.textContent += text.charAt(i);
            i++;
            setTimeout(typeWriter, 120);
        }
    })();

    // Form validation and EmailJS 
    const form = document.querySelector("form");
    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");

    // Error & success messages
    const nameError = document.createElement("p");
    nameError.classList.add("error");
    nameInput.after(nameError);

    const emailError = document.createElement("p");
    emailError.classList.add("error");
    emailInput.after(emailError);

    const successMsg = document.createElement("p");
    successMsg.style.textAlign = "center";
    successMsg.style.marginTop = "5px"; //
    form.appendChild(successMsg);

    function validateName() {
        const lettersOnly = /^[A-Za-z\s]+$/;
        if (!lettersOnly.test(nameInput.value.trim())) {
            nameError.textContent = "Name can only contain letters";
            return false;
        }
        nameError.textContent = "";
        return true;
    }

    function validateEmail() {
        const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!validEmail.test(emailInput.value.trim())) {
            emailError.textContent = "Please enter a valid email";
            return false;
        }
        emailError.textContent = "";
        return true;
    }

    nameInput.addEventListener("input", validateName);
    emailInput.addEventListener("input", validateEmail);

    // EmailJS integration
    emailjs.init("xyFB6iNQE9UFV0NJw");

    form.addEventListener("submit", (e) => {
        e.preventDefault();
        if (!validateName() || !validateEmail()) return;

        emailjs.sendForm("service_bw115ka", "template_ue4hjqq", form)
            .then(() => {
                successMsg.textContent = "Enquiry sent successfully!";
                successMsg.style.color = "#FFD700";
                form.reset();
            })
            .catch(err => {
                console.error(err);
                successMsg.textContent = "Oops! Something went wrong.";
                successMsg.style.color = "red";
            });
    });


});